#!/system/bin/sh
MODPATH=/data/adb/modules/mounthide
if [ -f "$MODPATH/mounthide.ko" ]; then
    insmod "$MODPATH/mounthide.ko" 2>/dev/null && echo "mounthide: loaded" >> /data/adb/ksu/log/mounthide.log 2>/dev/null || true
fi
